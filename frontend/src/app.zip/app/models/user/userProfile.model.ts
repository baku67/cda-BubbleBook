export interface UserProfil {
    username: string;
    email: string;
    isVerified: boolean;
    is2fa: boolean;
}