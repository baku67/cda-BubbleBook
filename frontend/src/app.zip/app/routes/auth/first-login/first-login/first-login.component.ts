import { Component } from '@angular/core';

@Component({
  selector: 'app-first-login',
  templateUrl: './first-login.component.html',
  styleUrl: './first-login.component.css'
})
export class FirstLoginComponent {

}
